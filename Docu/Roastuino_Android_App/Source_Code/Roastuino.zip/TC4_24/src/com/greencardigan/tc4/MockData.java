package com.greencardigan.tc4;


public class MockData {

	// x is the day number, 0, 1, 2, 3
	public static Point getDataFromReceiver(float x, float y)
	{
		return new Point(x, y);
	}
}
